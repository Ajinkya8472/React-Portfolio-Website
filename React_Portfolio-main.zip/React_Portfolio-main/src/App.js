import React, { useContext } from 'react';
import {
  BrowserRouter,
  Routes,
  Route
} from "react-router-dom";


import './App.css';

const App = () => {

  return (
    <BrowserRouter>
      <div id='top' className={`dark app`}>
        
        <main>
     
        </main>
        
     </div>
    </BrowserRouter>
  );
}

export default App;
